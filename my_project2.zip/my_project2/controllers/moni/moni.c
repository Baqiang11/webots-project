/*
 * Description: Demonstration of using sensors
 */
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <math.h>
#include <stdio.h>

#define TIME_STEP 10

#define START_STATE 1
#define DRIVE_FORWARDS_STATE 2
#define STOP_STATE 3
#define TURN_STATE 4
#define TURN_LEFT_STATE 5


WbDeviceTag motor_left;
WbDeviceTag motor_right;
WbDeviceTag s0,s1,s2,s3,s4,s5,s6;
WbDeviceTag g0, g1;
int state;
double Q;
/*
prox.horizontal.0 : front left
prox.horizontal.1 : front middle-left
prox.horizontal.2 : front middle
prox.horizontal.3 : front middle-right
prox.horizontal.4 : front right
prox.horizontal.5 : back left
prox.horizontal.6 : back right
*/

void init_devices() {
  motor_left = wb_robot_get_device("motor.left");
  motor_right = wb_robot_get_device("motor.right");
  s0 = wb_robot_get_device("prox.horizontal.0");
  s1 = wb_robot_get_device("prox.horizontal.1");
  s2 = wb_robot_get_device("prox.horizontal.2");
  s3 = wb_robot_get_device("prox.horizontal.3");
  s4 = wb_robot_get_device("prox.horizontal.4");
  s5 = wb_robot_get_device("prox.horizontal.5");
  s6 = wb_robot_get_device("prox.horizontal.6");
  wb_distance_sensor_enable(s0,100);
  wb_distance_sensor_enable(s1,100);
  wb_distance_sensor_enable(s2,100);
  wb_distance_sensor_enable(s3,100);
  wb_distance_sensor_enable(s4,100);
  wb_distance_sensor_enable(s5,100);
  wb_distance_sensor_enable(s6,100);
  g0 = wb_robot_get_device("prox.ground.0");
g1 = wb_robot_get_device("prox.ground.1");
wb_distance_sensor_enable(g0,100);
wb_distance_sensor_enable(g1,100);
  state = START_STATE;  
}

void setVelocity(double leftVel, double rightVel)
  {
   wb_motor_set_position(motor_left, INFINITY);
   wb_motor_set_position(motor_right, INFINITY);
   wb_motor_set_velocity(motor_left, leftVel);
   wb_motor_set_velocity(motor_right, rightVel);
  }

bool noObjectsNear()
// Returns true if front sensors are < 100
{
    double x0,x1,x2,x3,x4;
    x0 = wb_distance_sensor_get_value(s0);
    x1 = wb_distance_sensor_get_value(s1);
    x2 = wb_distance_sensor_get_value(s2);
    x3 = wb_distance_sensor_get_value(s3);
    x4 = wb_distance_sensor_get_value(s4);
    if ((x0 < 1000) && (x1 < 1000) && (x2 < 1000)&& (x3 < 1000)&& (x4 < 1000))
      return true; // No near objects
    else
      return false; // A least one sensor has detected something!!
}
bool turnL()
{
    double x3,x4;
    x3 = wb_distance_sensor_get_value(s3);
    x4 = wb_distance_sensor_get_value(s4);
    if ((x4 >50)||(x3 >50))
      return true; // No near objects
    else
      return false; // A least one sensor has detected something!!
}

bool turnR()
{
    double x0,x1;
    x0 = wb_distance_sensor_get_value(s0);
    x1 = wb_distance_sensor_get_value(s1);        
    if ((x0 >50)||(x1 >50))
      return true; // No near objects
    else
      return false; // A least one sensor has detected something!!
}

/*bool stop()
{  
   double x0,x1;
   x0 = wb_distance_sensor_get_value(g0);
x1 = wb_distance_sensor_get_value(g1);
printf("%f %f\n", x0, x1);
    if ((x0<200)||(x1<200))  
    return true; 
    else
      return false;

}*/

void makeRobotStop()
// Make a SYNCHRONOUS function to make the robot stop
// Issue a zero veloicty command and wait for some time .....
{
   int localT = 0;
   setVelocity(0,0);
   while ((wb_robot_step(TIME_STEP) != -1) && (localT < 500))
   {
     localT += TIME_STEP;
   }
}
void makeRobotTurn()
// Make a SYNCHRONOUS function to make the robot TURN
{
   int localT = 0;
   setVelocity(2,-2);
   while ((wb_robot_step(TIME_STEP) != -1) && (localT < 500))
   {
     localT += TIME_STEP;
   }
}

void makeRobotTurnLeft()
// Make a SYNCHRONOUS function to make the robot TURN
{
   int localT = 0;
   setVelocity(-2,2);
   while ((wb_robot_step(TIME_STEP) != -1) && (localT < 500))
   {
     localT += TIME_STEP;
   }
}


int main(int argc, char **argv) {
  double t = 0;
  double x0,x1;
  bool run = true;
  wb_robot_init();
  init_devices();
  while (wb_robot_step(TIME_STEP) != -1 && run) 
  {
    if ((state == START_STATE) && (t == 0))
    {
      
      state = DRIVE_FORWARDS_STATE;
    }
    else if ((state == DRIVE_FORWARDS_STATE) && (noObjectsNear()==true))
    {
      
      state = DRIVE_FORWARDS_STATE;
    }
    else if (state == DRIVE_FORWARDS_STATE) 
    {
      
      state = STOP_STATE;
    }
        else if((state == STOP_STATE) && (turnL()==true))
    {
      
     state = TURN_LEFT_STATE;
    }
    else if((state == STOP_STATE) &&(turnR()==true))
    {
      
      state = TURN_STATE;
    }

    
    else if ((state == TURN_STATE)||(state = TURN_LEFT_STATE))
    {
      
      state = DRIVE_FORWARDS_STATE;
    } 
  

    // Now we know what state we want, we need to issue some commands ...
    
  
    
    if (state == DRIVE_FORWARDS_STATE)
    {
    
      setVelocity(3,3);
    
    }
    else if (state == STOP_STATE)
    {
      makeRobotStop();
    }
    else if (state == TURN_STATE)
    {
      makeRobotTurn();
    }
    else if(state == TURN_LEFT_STATE)
    {
      makeRobotTurnLeft();
    }
    t += TIME_STEP;
    double x;
    double S;
    x += t;
    
    if(state == DRIVE_FORWARDS_STATE)
    {
    Q=t/300+1.5;
  //  printf("%f\n",Q);
    S= 3*Q*2.1;
    printf("distance is %fcm\n",S);
    }
    x0 = wb_distance_sensor_get_value(g0);
    x1 = wb_distance_sensor_get_value(g1);
    //printf("%f %f\n", x0, x1);
   
    if ((x0 < 200)||(x1<200)) { 
      run = false;
    }
    
    
    
  }
  
  while (true) {
    
  }
  
  
  wb_robot_cleanup();
  return 0;
}